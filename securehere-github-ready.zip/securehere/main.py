from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from urllib.parse import urlencode

app = FastAPI()

# Serve static files (CSS, JS, images)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Set templates folder
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def get_login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(
    name: str = Form(...),
    email: str = Form(...),
    location: str = Form(...),
    phone: str = Form(...)

):
    print(f"[ALERT] Woman logged in:\nName: {name}\nEmail: {email}\nLocation: {location}")
    params = urlencode({"name": name, "email": email, "location": location})
    return RedirectResponse(url=f"/success?{params}", status_code=303)

@app.get("/success", response_class=HTMLResponse)
async def success(request: Request):
    name = request.query_params.get("name", "")
    email = request.query_params.get("email", "")
    location = request.query_params.get("location", "")
    return templates.TemplateResponse("success.html", {
        "request": request,
        "name": name,
        "email": email,
        "location": location
    })

@app.get("/location-tracked", response_class=HTMLResponse)
async def location_tracked(request: Request):
    return templates.TemplateResponse("tracked.html", {"request": request})
