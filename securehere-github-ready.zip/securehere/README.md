# SecureHer – Women's Safety Alert Form (FastAPI prototype)

A small web prototype for a women's-safety alert flow. A user fills in a form with their name,
email, 11-digit phone number and location; the server records an alert and shows a confirmation page.

> **Status: prototype.** The alert is currently only printed to the server console. Real location
> tracking, notifications to contacts/authorities, accounts and a database are not implemented yet
> (see Roadmap).

## Tech stack
- **Python 3** with **FastAPI** (backend routes) and **Uvicorn** (server)
- **Jinja2** templates (server-rendered **HTML5**)
- **CSS3** (responsive layout, gradient UI)

## Features
- Alert form with required fields and basic client-side validation (email format, 11-digit phone pattern)
- `POST /login` handler that receives the form data and logs an alert on the server
- Confirmation page (`/success`) that greets the user by name
- "Location tracked" confirmation page (`/location-tracked`)

## Run locally
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```
Open http://127.0.0.1:8000

## Project structure
```
main.py                 FastAPI app and routes
templates/              login.html, success.html, tracked.html (Jinja2)
static/style.css        styling
```

## Roadmap (planned improvements)
- Password-based registration/login with hashed passwords and session management
- Database storage (e.g. SQLite/PostgreSQL) for users and alerts
- Server-side input validation and CSRF protection
- Send personal data via POST/session only (not in URLs)
- Real alert delivery (SMS/email to trusted contacts) and browser geolocation with user consent
